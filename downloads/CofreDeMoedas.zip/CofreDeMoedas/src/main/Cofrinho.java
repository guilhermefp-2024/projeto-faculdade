package main;

import moedas.Moeda;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa um cofrinho que pode armazenar diferentes moedas.
 */
public class Cofrinho {
    private List<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();  // Inicializa a lista de moedas.
    }

    /**
     * Adiciona uma moeda ao cofrinho.
     * @param moeda A moeda a ser adicionada.
     */
    public void adicionarMoeda(Moeda moeda) {
        moedas.add(moeda);
    }

    /**
     * Remove uma moeda específica do cofrinho.
     * @param moeda A moeda a ser removida.
     */
    public void removerMoeda(Moeda moeda) {
        moedas.remove(moeda);
    }

    /**
     * Lista todas as moedas presentes no cofrinho.
     */
    public void listarMoedas() {
        for (Moeda moeda : moedas) {
            System.out.println(moeda.info());
        }
    }

    /**
     * Calcula o valor total de todas as moedas no cofrinho, convertido para Reais.
     * @return O valor total em Reais.
     */
    public double calcularTotalEmReais() {
        double total = 0;
        for (Moeda moeda : moedas) {
            total += moeda.converterParaReal();  // Converte cada moeda para Real e soma ao total.
        }
        return total;
    }

    public List<Moeda> getMoedas() {
        return moedas;  // Retorna a lista de moedas.
    }
}
