package main;

import util.Menu;

/**
 * Classe principal que inicia o programa.
 */
public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.exibirMenu();  // Exibe o menu para interação do usuário.
    }
}
