package util;

import main.Cofrinho;
import moedas.Dolar;
import moedas.Euro;
import moedas.Moeda;
import moedas.Real;
import java.util.Scanner;

/**
 * Classe responsável por exibir o menu e interagir com o usuário.
 */
public class Menu {
    private Cofrinho cofrinho;
    private Scanner scanner;

    public Menu() {
        cofrinho = new Cofrinho();  // Inicializa o cofrinho.
        scanner = new Scanner(System.in);  // Inicializa o scanner para leitura de entradas do usuário.
    }

    /**
     * Exibe o menu e lida com as opções escolhidas pelo usuário.
     */
    public void exibirMenu() {
        int opcao;
        do {
            System.out.println("1. Adicionar Moeda");
            System.out.println("2. Remover Moeda");
            System.out.println("3. Listar Moedas");
            System.out.println("4. Calcular Total em Reais");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();  // Lê a opção escolhida pelo usuário.

            switch (opcao) {
                case 1:
                    adicionarMoeda();  // Chama o método para adicionar moeda.
                    break;
                case 2:
                    removerMoeda();  // Chama o método para remover moeda.
                    break;
                case 3:
                    cofrinho.listarMoedas();  // Lista todas as moedas no cofrinho.
                    System.out.println();  // Adiciona uma linha em branco para melhor formatação.
                    break;
                case 4:
                    System.out.println("Total em Reais: " + cofrinho.calcularTotalEmReais());
                    System.out.println();  // Adiciona uma linha em branco para melhor formatação.
                    break;
                case 0:
                    System.out.println("Saindo...");
                    System.out.println();  // Adiciona uma linha em branco para melhor formatação.
                    break;
                default:
                    System.out.println("Opção inválida!");
                    System.out.println();  // Adiciona uma linha em branco para melhor formatação.
            }
        } while (opcao != 0);

        scanner.close();  // Fecha o scanner ao sair do loop.
    }

    /**
     * Adiciona uma moeda ao cofrinho.
     */
    private void adicionarMoeda() {
        System.out.println("Escolha o tipo de moeda:");
        System.out.println("1. Dólar");
        System.out.println("2. Euro");
        System.out.println("3. Real");
        int tipo = scanner.nextInt();  // Lê o tipo de moeda escolhido pelo usuário.

        System.out.print("Digite o valor: ");
        double valor = scanner.nextDouble();  // Lê o valor da moeda.

        Moeda moeda = null;
        switch (tipo) {
            case 1:
                moeda = new Dolar(valor);
                break;
            case 2:
                moeda = new Euro(valor);
                break;
            case 3:
                moeda = new Real(valor);
                break;
            default:
                System.out.println("Tipo de moeda inválido!");
                System.out.println();  // Adiciona uma linha em branco para melhor formatação.
        }

        if (moeda != null) {
            cofrinho.adicionarMoeda(moeda);  // Adiciona a moeda ao cofrinho.
            System.out.println("Moeda adicionada com sucesso!");
            System.out.println();  // Adiciona uma linha em branco para melhor formatação.
        }
    }

    /**
     * Remove uma moeda específica do cofrinho.
     */
    private void removerMoeda() {
        System.out.print("Digite o valor da moeda a ser removida: ");
        double valor = scanner.nextDouble();  // Lê o valor da moeda a ser removida.

        Moeda moedaARemover = null;
        for (Moeda moeda : cofrinho.getMoedas()) {
            if (moeda.getValor() == valor) {
                moedaARemover = moeda;  // Encontra a moeda a ser removida.
                break;
            }
        }

        if (moedaARemover != null) {
            cofrinho.removerMoeda(moedaARemover);  // Remove a moeda do cofrinho.
            System.out.println("Moeda removida com sucesso!");
            System.out.println(); 
        } else {
            System.out.println("Moeda não encontrada!");
            System.out.println();  
        }
    }
}
