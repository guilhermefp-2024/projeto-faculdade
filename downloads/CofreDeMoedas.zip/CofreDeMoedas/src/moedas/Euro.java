package moedas;

/**
 * Classe que representa uma moeda em Euro.
 */
public class Euro extends Moeda {
    public Euro(double valor) {
        super(valor, "Euro");
    }

    @Override
    public double converterParaReal() {
        return valor * 6.0; // Converte Euro para Real usando uma taxa fictícia.
    }
}
