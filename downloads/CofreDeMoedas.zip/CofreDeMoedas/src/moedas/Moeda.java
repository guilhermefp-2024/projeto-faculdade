package moedas;

/**
 * Classe abstrata que representa uma moeda.
 */
public abstract class Moeda {
    protected double valor;
    protected String pais;

    public Moeda(double valor, String pais) {
        this.valor = valor;
        this.pais = pais;
    }

    /**
     * Método abstrato para converter o valor da moeda para Reais.
     * @return O valor convertido para Reais.
     */
    public abstract double converterParaReal();

    /**
     * Retorna informações sobre a moeda.
     * @return Uma string contendo informações sobre a moeda.
     */
    public String info() {
        return "Moeda: " + pais + ", Valor: " + valor;
    }

    public double getValor() {
        return valor;
    }
}
