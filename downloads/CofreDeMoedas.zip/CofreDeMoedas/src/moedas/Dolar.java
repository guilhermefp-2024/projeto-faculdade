package moedas;

/**
 * Classe que representa uma moeda em Dólar.
 */
public class Dolar extends Moeda {
    public Dolar(double valor) {
        super(valor, "Dólar");
    }

    @Override
    public double converterParaReal() {
        return valor * 5.0; // Converte Dólar para Real usando uma taxa fictícia.
    }
}
