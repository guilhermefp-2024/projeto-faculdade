package moedas;

/**
 * Classe que representa uma moeda em Real.
 */
public class Real extends Moeda {
    public Real(double valor) {
        super(valor, "Real");
    }

    @Override
    public double converterParaReal() {
        return valor; // Não há necessidade de conversão, pois já está em Reais.
    }
}
